export interface Subject{
    id: number;
    subjectname: 'String';
    credits: number;
    semester: 'String';
    year: number;
}