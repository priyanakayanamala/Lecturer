export interface Lecturer{
    id: number;
    name: 'String';
    email: 'String';
    phone: number;
}